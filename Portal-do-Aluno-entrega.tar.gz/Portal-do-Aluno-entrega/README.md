# Portal Unificado do Aluno

Projeto acadêmico do curso de Análise e Desenvolvimento de Sistemas.

## Estrutura

- frontend/: interface web em Django.
- backend/: API Django REST Framework.
- compose.yaml: configuração dos contêineres.

## Requisitos

- Docker instalado.
- Docker Compose disponível pelo comando docker compose.

## Configuração inicial

Na pasta raiz, execute:

    cp backend/.env.example backend/.env
    cp frontend/.env.example frontend/.env

Edite os dois arquivos .env e substitua SUBSTITUA_POR_UMA_CHAVE_SEGURA por chaves secretas diferentes.

Para gerar uma chave segura, execute duas vezes:

    python3 -c "import secrets; print(secrets.token_urlsafe(50))"

Não compartilhe os arquivos .env.

## Inicialização

Na pasta raiz:

    docker compose up --build

## Acesso

- Frontend: http://localhost:8001
- Backend: http://localhost:8000

## Encerramento

Para parar os serviços sem apagar os bancos:

    docker compose down

Para apagar também os volumes e os dados persistidos:

    docker compose down -v

ATENÇÃO: o segundo comando apaga os dados armazenados nos volumes.

## Integrações

As integrações com Moodle, Cerbrum e Sectras dependem das URLs e credenciais institucionais configuradas no backend/.env.

## Observação técnica

A configuração utiliza o servidor de desenvolvimento do Django (runserver), adequado para demonstração acadêmica, não para produção.
