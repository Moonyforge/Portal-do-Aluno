
import json
import uuid
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen

from django.conf import settings


class APIError(Exception):
    def __init__(self, status, data):
        self.status = status
        self.data = data
        super().__init__(str(data))


def _base_url():
    return getattr(
        settings,
        "BACKEND_API_URL",
        "http://127.0.0.1:8000/api",
    ).rstrip("/")


def _request(url, method="GET", headers=None, body=None, timeout=10):
    request = Request(
        url,
        data=body,
        headers=headers or {},
        method=method.upper(),
    )

    try:
        with urlopen(request, timeout=timeout) as response:
            content = response.read()
            return json.loads(content) if content else None

    except HTTPError as error:
        content = error.read().decode("utf-8", errors="replace")
        try:
            details = json.loads(content)
        except json.JSONDecodeError:
            details = {"detail": "Erro na comunicação com o servidor."}
        raise APIError(error.code, details) from error

    except (URLError, TimeoutError) as error:
        raise APIError(
            503,
            {"detail": "Não foi possível conectar ao servidor do portal."},
        ) from error


def _renovar_token(session):
    refresh = session.get("api_refresh")

    if not refresh:
        return None

    try:
        resposta = _request(
            f"{_base_url()}/auth/refresh/",
            method="POST",
            headers={
                "Accept": "application/json",
                "Content-Type": "application/json",
            },
            body=json.dumps({"refresh": refresh}).encode("utf-8"),
        )

        access = resposta.get("access")
        novo_refresh = resposta.get("refresh")

        if not access:
            session.flush()
            return None

        session["api_access"] = access

        if novo_refresh:
            session["api_refresh"] = novo_refresh

        return access

    except APIError as error:
        if error.status in (400, 401):
            session.flush()
            return None
        raise


def _montar_corpo(data=None, files=None):
    if not files:
        if data is None:
            return None, {}

        return (
            json.dumps(data).encode("utf-8"),
            {"Content-Type": "application/json"},
        )

    boundary = uuid.uuid4().hex
    partes = []

    for campo, valor in (data or {}).items():
        partes.append(
            (
                f"--{boundary}\r\n"
                f'Content-Disposition: form-data; name="{campo}"\r\n\r\n'
                f"{valor}\r\n"
            ).encode("utf-8")
        )

    for campo, arquivo in files.items():
        nome = arquivo.name.rsplit("/", 1)[-1].replace('"', "")
        tipo = getattr(arquivo, "content_type", None) or "application/pdf"
        conteudo = arquivo.read()

        partes.append(
            (
                f"--{boundary}\r\n"
                f'Content-Disposition: form-data; name="{campo}"; filename="{nome}"\r\n'
                f"Content-Type: {tipo}\r\n\r\n"
            ).encode("utf-8")
            + conteudo
            + b"\r\n"
        )

    partes.append(f"--{boundary}--\r\n".encode("utf-8"))

    return (
        b"".join(partes),
        {"Content-Type": f"multipart/form-data; boundary={boundary}"},
    )


def api_request(
    path,
    method="GET",
    token=None,
    data=None,
    files=None,
    session=None,
):
    body, content_headers = _montar_corpo(data, files)

    if session is not None and session.get("api_access"):
        token = session["api_access"]

    headers = {
        "Accept": "application/json",
        **content_headers,
    }

    if token:
        headers["Authorization"] = f"Bearer {token}"

    url = f"{_base_url()}/{path.lstrip('/')}"

    try:
        return _request(
            url,
            method=method,
            headers=headers,
            body=body,
        )

    except APIError as error:
        if error.status != 401 or session is None:
            raise

        novo_access = _renovar_token(session)

        if not novo_access:
            raise

        headers["Authorization"] = f"Bearer {novo_access}"

        return _request(
            url,
            method=method,
            headers=headers,
            body=body,
        )


def api_download(path, token, session=None):
    if session is not None and session.get("api_access"):
        token = session["api_access"]

    headers = {
        "Accept": "application/pdf",
        "Authorization": f"Bearer {token}",
    }

    url = f"{_base_url()}/{path.lstrip('/')}"

    def baixar():
        request = Request(
            url,
            headers=headers,
            method="GET",
        )

        try:
            with urlopen(request, timeout=15) as response:
                return (
                    response.read(),
                    response.headers.get("Content-Type", "application/pdf"),
                )

        except HTTPError as error:
            content = error.read().decode("utf-8", errors="replace")
            try:
                details = json.loads(content)
            except json.JSONDecodeError:
                details = {"detail": "Não foi possível baixar o documento."}
            raise APIError(error.code, details) from error

        except (URLError, TimeoutError) as error:
            raise APIError(
                503,
                {"detail": "Não foi possível conectar ao servidor do portal."},
            ) from error

    try:
        return baixar()

    except APIError as error:
        if error.status != 401 or session is None:
            raise

        novo_access = _renovar_token(session)

        if not novo_access:
            raise

        headers["Authorization"] = f"Bearer {novo_access}"
        return baixar()
